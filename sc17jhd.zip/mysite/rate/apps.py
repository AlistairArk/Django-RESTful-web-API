from django.apps import AppConfig


class RateConfig(AppConfig):
    name = 'rate'
